"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Fingerprint,
  Shield,
  Lock,
  Globe,
  Mail,
  Vote,
  Heart,
  GraduationCap,
  MessageSquare,
  Scan,
  ChevronRight,
  Check,
} from "lucide-react"
import { cn } from "@/lib/utils"

export default function HomePage() {
  const [activeView, setActiveView] = useState<"landing" | "dashboard">("landing")
  const [enrollmentStep, setEnrollmentStep] = useState(0)

  if (activeView === "landing") {
    return <LandingView onGetStarted={() => setActiveView("dashboard")} />
  }

  return <DashboardView />
}

function LandingView({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-b from-primary/5 to-background">
        <div className="container mx-auto px-4 py-12">
          <div className="flex flex-col items-center text-center max-w-3xl mx-auto space-y-6">
            <div className="flex items-center gap-2 mb-2">
              <Fingerprint className="h-10 w-10 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">BDI</h1>
            </div>

            <h2 className="text-4xl md:text-5xl font-bold text-balance leading-tight">Your Global Digital Identity</h2>

            <p className="text-lg text-muted-foreground text-balance leading-relaxed">
              A universal biometric identity platform using facial recognition to generate a unique, secure, and
              globally valid digital identity. Replace phone numbers and usernames with your Bio-ID.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto pt-4">
              <Button size="lg" className="text-base" onClick={onGetStarted}>
                Get Started
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" className="text-base bg-transparent">
                Learn More
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center gap-8 pt-8 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-accent" />
                <span>Military-grade encryption</span>
              </div>
              <div className="flex items-center gap-2">
                <Lock className="h-4 w-4 text-accent" />
                <span>Secure enclaves</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="h-4 w-4 text-accent" />
                <span>Globally recognized</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold mb-3 text-balance">One Identity. Infinite Possibilities.</h3>
          <p className="text-muted-foreground text-balance">Access all services with your secure Bio-ID</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
          <FeatureCard
            icon={<MessageSquare className="h-6 w-6" />}
            title="Communication"
            description="Message and call anyone using Bio-ID. No phone numbers required."
          />
          <FeatureCard
            icon={<Vote className="h-6 w-6" />}
            title="Voting & Elections"
            description="Secure, transparent, and verifiable digital voting powered by biometrics."
          />
          <FeatureCard
            icon={<Heart className="h-6 w-6" />}
            title="Health Records"
            description="Access your complete medical history securely from anywhere."
          />
          <FeatureCard
            icon={<Mail className="h-6 w-6" />}
            title="Digital Mail"
            description="Encrypted messaging and document delivery tied to your identity."
          />
          <FeatureCard
            icon={<GraduationCap className="h-6 w-6" />}
            title="Education Verification"
            description="Instant verification of credentials and academic achievements."
          />
          <FeatureCard
            icon={<Shield className="h-6 w-6" />}
            title="Privacy First"
            description="Your biometric data never leaves secure enclaves. You control access."
          />
        </div>
      </div>

      {/* How It Works */}
      <div className="bg-muted/30 py-16">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12 text-balance">How Bio-ID Works</h3>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="flex flex-col items-center text-center space-y-3">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
                1
              </div>
              <h4 className="font-semibold text-lg">Enroll Biometrics</h4>
              <p className="text-sm text-muted-foreground">
                Securely capture your facial biometrics to create your unique Bio-ID template
              </p>
            </div>

            <div className="flex flex-col items-center text-center space-y-3">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
                2
              </div>
              <h4 className="font-semibold text-lg">Generate Identity</h4>
              <p className="text-sm text-muted-foreground">
                AI processes your biometrics into a non-reversible secure token stored in encrypted enclaves
              </p>
            </div>

            <div className="flex flex-col items-center text-center space-y-3">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
                3
              </div>
              <h4 className="font-semibold text-lg">Access Services</h4>
              <p className="text-sm text-muted-foreground">
                Use your Bio-ID across all platforms - voting, healthcare, communication, and more
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Security Features */}
      <div className="container mx-auto px-4 py-16">
        <h3 className="text-3xl font-bold text-center mb-12 text-balance">Enterprise-Grade Security</h3>

        <div className="grid sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
          <SecurityFeature
            icon={<Lock className="h-5 w-5" />}
            title="Secure Enclaves"
            description="Biometric data processed in isolated hardware environments"
          />
          <SecurityFeature
            icon={<Shield className="h-5 w-5" />}
            title="Non-Reversible Templates"
            description="Mathematical transformation prevents reconstruction of original biometrics"
          />
          <SecurityFeature
            icon={<Check className="h-5 w-5" />}
            title="Consent-Based Access"
            description="You explicitly approve every data access request"
          />
          <SecurityFeature
            icon={<Globe className="h-5 w-5" />}
            title="Immutable Audit Trails"
            description="Complete transparency on who accessed your data and when"
          />
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold mb-4 text-balance">Ready to Join the Future?</h3>
          <p className="text-primary-foreground/90 mb-8 max-w-2xl mx-auto text-balance">
            Create your Bio-ID today and experience seamless, secure access to all digital services
          </p>
          <Button size="lg" variant="secondary" onClick={onGetStarted}>
            Create Your Bio-ID
            <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

function DashboardView() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Fingerprint className="h-6 w-6 text-primary" />
              <span className="font-bold text-lg">BDI</span>
            </div>
            <Button variant="ghost" size="sm">
              <Scan className="h-4 w-4 mr-2" />
              Verify
            </Button>
          </div>
        </div>
      </header>

      {/* Identity Card */}
      <div className="container mx-auto px-4 py-6">
        <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground border-0 overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <p className="text-primary-foreground/80 text-sm mb-1">Bio-ID</p>
                <p className="text-2xl font-mono font-bold">BDI-7A4K-9MX2</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                <Fingerprint className="h-6 w-6" />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Check className="h-4 w-4" />
                <span>Identity Verified</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Shield className="h-4 w-4" />
                <span>Biometric Protected</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Globe className="h-4 w-4" />
                <span>Globally Recognized</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Services Grid */}
      <div className="container mx-auto px-4 pb-8">
        <h2 className="text-xl font-bold mb-4">Your Services</h2>

        <div className="grid grid-cols-2 gap-3">
          <ServiceCard
            icon={<MessageSquare className="h-6 w-6" />}
            title="Messages"
            description="3 new"
            color="bg-blue-500"
          />
          <ServiceCard
            icon={<Vote className="h-6 w-6" />}
            title="Voting"
            description="2 active polls"
            color="bg-purple-500"
          />
          <ServiceCard
            icon={<Heart className="h-6 w-6" />}
            title="Health"
            description="View records"
            color="bg-red-500"
          />
          <ServiceCard icon={<Mail className="h-6 w-6" />} title="Mail" description="12 unread" color="bg-green-500" />
          <ServiceCard
            icon={<GraduationCap className="h-6 w-6" />}
            title="Education"
            description="2 credentials"
            color="bg-amber-500"
          />
          <ServiceCard
            icon={<Shield className="h-6 w-6" />}
            title="Security"
            description="Manage access"
            color="bg-slate-500"
          />
        </div>
      </div>

      {/* Recent Activity */}
      <div className="container mx-auto px-4 pb-8">
        <h2 className="text-xl font-bold mb-4">Recent Activity</h2>
        <Card>
          <CardContent className="p-0 divide-y">
            <ActivityItem
              icon={<Check className="h-4 w-4 text-green-500" />}
              title="Identity Verified"
              time="2 hours ago"
            />
            <ActivityItem
              icon={<Mail className="h-4 w-4 text-blue-500" />}
              title="New secure message from Health Services"
              time="5 hours ago"
            />
            <ActivityItem
              icon={<Vote className="h-4 w-4 text-purple-500" />}
              title="Participated in Community Poll"
              time="1 day ago"
            />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-3">
          {icon}
        </div>
        <CardTitle className="text-lg">{title}</CardTitle>
        <CardDescription className="text-sm leading-relaxed">{description}</CardDescription>
      </CardHeader>
    </Card>
  )
}

function SecurityFeature({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="flex gap-4">
      <div className="h-10 w-10 rounded-lg bg-accent/10 flex items-center justify-center text-accent flex-shrink-0">
        {icon}
      </div>
      <div>
        <h4 className="font-semibold mb-1">{title}</h4>
        <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
      </div>
    </div>
  )
}

function ServiceCard({
  icon,
  title,
  description,
  color,
}: { icon: React.ReactNode; title: string; description: string; color: string }) {
  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer">
      <CardContent className="p-4">
        <div className={cn("h-10 w-10 rounded-lg flex items-center justify-center text-white mb-3", color)}>{icon}</div>
        <h3 className="font-semibold mb-1">{title}</h3>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  )
}

function ActivityItem({ icon, title, time }: { icon: React.ReactNode; title: string; time: string }) {
  return (
    <div className="flex items-start gap-3 p-4">
      <div className="mt-0.5">{icon}</div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium leading-relaxed">{title}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{time}</p>
      </div>
    </div>
  )
}
